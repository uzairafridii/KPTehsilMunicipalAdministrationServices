package com.uzair.kptehsilmunicipaladministrationservices.UserComplaint.ComplaintsMain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.uzair.kptehsilmunicipaladministrationservices.R;

public class AddComplaints extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_complaints);
    }
}
