package com.uzair.kptehsilmunicipaladministrationservices.WaterBills;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.uzair.kptehsilmunicipaladministrationservices.R;

public class WaterBills extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_bills);

    }
}
